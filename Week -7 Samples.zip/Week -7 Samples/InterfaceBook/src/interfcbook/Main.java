package interfcbook;

public interface Main {
	   public static void main(String[]arg){
			Book book1= new BookImpl("The Great Gatsby", "F. Scott Fitzgerald", "9780743273565");
		     System.out.println  ("Title: " + book1.getTitle());
		     System.out.println("Author: " + book1.getAuthor());
		     System.out.println("ISBN: " + book1.getISBN());
		}
}