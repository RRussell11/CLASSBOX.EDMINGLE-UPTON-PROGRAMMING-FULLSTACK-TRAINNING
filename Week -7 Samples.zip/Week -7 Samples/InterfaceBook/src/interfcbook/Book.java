
package interfcbook;

//import interfacebook.Book;
//import interfacebook.BookImplementation;

public interface Book {
  String getTitle();
  String getAuthor();
  String getISBN();
}
class BookImpl implements Book{
	private String title;
	private String author;
	private String isbn;
	
	public BookImpl(String title, String author, String isbn) {
    this.title= title;
    this.author=author;
    this.isbn=isbn;
	}
@Override
public  String getTitle() {
	return title;
	}
public  String getAuthor() {
	return author;
	} 
@Override

public String getISBN() {
	return isbn;
}

}




	
