package interfclib;

   public interface MainLib {
   public static void main(String[] args) {
				Library library = new LibraryImpl();
				//library.addBook("NorthWoods", "JohnDoe", "novel");
				//library.searchTitle();
				//library.displayBooks();
				
				Book foundBook = library.searchTitle("NorthWoods");
		        if (foundBook != null) {
		            System.out.println("Found book: " + foundBook.getTitle() + " by " + ((Object) foundBook).getAuthor());
		        } else {
		            System.out.println("Book not found.");
		        }
}
	 }
