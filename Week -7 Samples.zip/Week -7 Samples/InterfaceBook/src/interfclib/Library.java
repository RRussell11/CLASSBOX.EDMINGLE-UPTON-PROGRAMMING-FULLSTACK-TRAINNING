package interfclib;

public interface Library {


	// addBook(Book book), searchByTitle(String title), searchByAuthor(String
	// author), and displayBooks().

	String addBook(Book book);

	Book  searchTitle(String title);

	String displayBooks();

	String  addBook(String string, String string2, String string3);

}

class LibraryImpl implements Library {
	private Book book;
	@SuppressWarnings("unused")
	private String title;
	@SuppressWarnings("unused")
	private String displaybooks;
	
	  @Override
	    public void addBook(Book book) {
	        this.book = book;
	    }
	

	@Override
	public Book searchTitle(String title) {
	
	       if (book != null && book.getTitle().equalsIgnoreCase(title)) {
	            return book;
	        }
	        return null;
	    }

	@Override
	public Book displayBooks() {
		
		return book;
	}


	@Override
	public void addBook(String string, String string2, String string3) {
		// TODO Auto-generated method stub
		
	}

		
		
	}

    
	
	
	

